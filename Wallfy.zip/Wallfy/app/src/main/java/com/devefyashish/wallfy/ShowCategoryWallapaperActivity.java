package com.devefyashish.wallfy;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.os.Bundle;
import android.widget.AbsListView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ShowCategoryWallapaperActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private String catname;

    private WallPaperAdapter wallPaperAdapter;
    private List<WallPaperModel> wallPaperModelList = new ArrayList<>();

    private String MyGetImagesLink = "https://pixabay.com/api/";
    private String MyApi = "18578333-0e956c2bd5c8ed9e7e7af54b3";
    String URL = "https://pixabay.com/api/?key="+MyApi;

    private boolean isScrolling= false;
    private int currentItems, totalItems, scrolloutItems;
    int pageNumber=1,per_page=50;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_category_wallapaper);

        catname=getIntent().getStringExtra("catname").toLowerCase();
        recyclerView=findViewById(R.id.show_wallaper_Category_recyclerview);

        fetchData();

        wallPaperAdapter = new WallPaperAdapter(wallPaperModelList,this);
        final GridLayoutManager gridLayoutManager = new GridLayoutManager(this, 2, GridLayoutManager.VERTICAL, false);
        recyclerView.setLayoutManager(gridLayoutManager);


        recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(@NonNull RecyclerView recyclerView, int newState) {
                super.onScrollStateChanged(recyclerView, newState);

                if(newState == AbsListView.OnScrollListener.SCROLL_STATE_TOUCH_SCROLL){
                    isScrolling=true;
                }

            }

            @Override
            public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);

                currentItems=gridLayoutManager.getChildCount();
                totalItems=gridLayoutManager.getItemCount();
                scrolloutItems=gridLayoutManager.findFirstVisibleItemPosition();

                if(isScrolling && (currentItems+scrolloutItems==totalItems)  ){
                    isScrolling=false;
                    fetchData();
                }

            }
        });


        recyclerView.setAdapter(wallPaperAdapter);
        wallPaperAdapter.notifyDataSetChanged();


    }

    private void fetchData() {

        StringRequest request = new StringRequest(Request.Method.GET, URL+"&category="+catname+"&page="+pageNumber+"&per_page="+per_page,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        wallPaperModelList.clear();
                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            JSONArray jsonArray = jsonObject.getJSONArray("hits");
                            int length = jsonArray.length();

                            for (int i = 0; i < length; i++) {

                                JSONObject jsonObject1 = jsonArray.getJSONObject(i);

                                String id = jsonObject1.getString("id");

                                String image = jsonObject1.getString("largeImageURL");

                                wallPaperModelList.add(new WallPaperModel(id, image));

                            }

                            wallPaperAdapter.notifyDataSetChanged();
                            pageNumber++;

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }


                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                Toast.makeText(ShowCategoryWallapaperActivity.this, "Images Not Found !!!", Toast.LENGTH_SHORT).show();


            }
        }) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {

                Map<String, String> map = new HashMap<>();
                map.put("key", MyApi);
                return map;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(ShowCategoryWallapaperActivity.this);
        requestQueue.add(request);

    }

}

