package com.devefyashish.wallfy;

public class WallPaperModel {
    String id,link;

    public WallPaperModel() {
    }

    public WallPaperModel(String id, String link) {
        this.id = id;
        this.link = link;
    }

    public String getId() {
        return id;
    }

    public String getLink() {
        return link;
    }
}
