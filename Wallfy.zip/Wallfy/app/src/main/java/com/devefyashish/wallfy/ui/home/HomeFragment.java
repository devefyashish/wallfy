package com.devefyashish.wallfy.ui.home;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.devefyashish.wallfy.R;
import com.devefyashish.wallfy.WallPaperAdapter;
import com.devefyashish.wallfy.WallPaperModel;
import com.efaso.admob_advanced_native_recyvlerview.AdmobNativeAdAdapter;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class HomeFragment extends Fragment {

    private RecyclerView recyclerView;
    private WallPaperAdapter wallPaperAdapter;
    private List<WallPaperModel> wallPaperModelList = new ArrayList<>();


    private String MyGetImagesLink = "https://pixabay.com/api/";

    private String MyApi = "Add Here Your API KEy HERE FROm PIXABAY ";
    String URL = "https://pixabay.com/api/?key="+MyApi;



    private boolean isScrolling= false;
    private int currentItems, totalItems, scrolloutItems;


    int pageNumber=1,per_page=50;

    private AdView mAdView;

    public static AdmobNativeAdAdapter admobNativeAdAdapter;


    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_home, container, false);


        MobileAds.initialize(getContext(), new OnInitializationCompleteListener() {
            @Override
            public void onInitializationComplete(InitializationStatus initializationStatus) {

            }
        });

        mAdView = view.findViewById(R.id.adView);
        AdRequest adRequest = new AdRequest.Builder().build();
        mAdView.loadAd(adRequest);


        recyclerView = view.findViewById(R.id.home_recyclerview);
        fetchData();

        wallPaperAdapter = new WallPaperAdapter(wallPaperModelList, getContext());
        final GridLayoutManager gridLayoutManager = new GridLayoutManager(getContext(), 2, GridLayoutManager.VERTICAL, false);
        recyclerView.setLayoutManager(gridLayoutManager);


        admobNativeAdAdapter = AdmobNativeAdAdapter.Builder
                .with("ca-app-pub-3940256099942544/2247696110",
                        wallPaperAdapter, "custom")
                .adItemIterval(3)//native ad repeating interval in the recyclerview
                .build();

        recyclerView.setAdapter(admobNativeAdAdapter);


        recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(@NonNull RecyclerView recyclerView, int newState) {
                super.onScrollStateChanged(recyclerView, newState);

                if(newState == AbsListView.OnScrollListener.SCROLL_STATE_TOUCH_SCROLL){
                    isScrolling=true;
                }

            }

            @Override
            public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);

                currentItems=gridLayoutManager.getChildCount();
                totalItems=gridLayoutManager.getItemCount();
                scrolloutItems=gridLayoutManager.findFirstVisibleItemPosition();

                if(isScrolling && (currentItems+scrolloutItems==totalItems)  ){
                    isScrolling=false;
                    fetchData();
                }

            }
        });
        wallPaperAdapter.notifyDataSetChanged();

        return view;
    }

    private void fetchData() {

        StringRequest request = new StringRequest(Request.Method.GET, URL+"&page="+pageNumber+"&per_page="+per_page,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            JSONArray jsonArray = jsonObject.getJSONArray("hits");
                            int length = jsonArray.length();

                            for (int i = 0; i < length; i++) {

                                JSONObject jsonObject1 = jsonArray.getJSONObject(i);

                                String id = jsonObject1.getString("id");

                                String image = jsonObject1.getString("largeImageURL");

                                wallPaperModelList.add(new WallPaperModel(id, image));

                            }

                            wallPaperAdapter.notifyDataSetChanged();
                            pageNumber++;

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }


                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                Toast.makeText(getContext(), "Images Not Found !!!", Toast.LENGTH_SHORT).show();


            }
        }) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {

                Map<String, String> map = new HashMap<>();
                map.put("key", MyApi);
                return map;
            }
        };

        Context context = getActivity();
        RequestQueue requestQueue = Volley.newRequestQueue(context);
        requestQueue.add(request);

    }

}