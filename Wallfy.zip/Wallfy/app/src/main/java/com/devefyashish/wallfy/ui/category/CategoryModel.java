package com.devefyashish.wallfy.ui.category;

public class CategoryModel {
    String catname, catimg;

    public CategoryModel(String catname, String catimg) {
        this.catname = catname;
        this.catimg = catimg;
    }

    public String getCatname() {
        return catname;
    }

    public String getCatimg() {
        return catimg;
    }
}
