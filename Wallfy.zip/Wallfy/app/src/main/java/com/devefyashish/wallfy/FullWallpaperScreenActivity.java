package com.devefyashish.wallfy;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DownloadManager;
import android.app.ProgressDialog;
import android.app.WallpaperManager;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.github.chrisbanes.photoview.PhotoView;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;

import java.io.File;
import java.io.IOException;
import java.util.UUID;

public class FullWallpaperScreenActivity extends AppCompatActivity {

    private Button button1,button2,button3;
    private PhotoView photoView;
    private String imgLink;

    private ProgressDialog progressBar;
    private String filename;

    private InterstitialAd mInterstitialAd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_full_wallpaper_screen);

        MobileAds.initialize(this, new OnInitializationCompleteListener() {
            @Override
            public void onInitializationComplete(InitializationStatus initializationStatus) {}
        });

        mInterstitialAd = new InterstitialAd(this);
        mInterstitialAd.setAdUnitId("ca-app-pub-3940256099942544/1033173712");
        mInterstitialAd.loadAd(new AdRequest.Builder().build());



        imgLink=getIntent().getStringExtra("img");

        photoView =findViewById(R.id.full_screen_img);
        Glide.with(this).load(imgLink).into(photoView);


        button1=findViewById(R.id.download_wallapper_btn);
        button2=findViewById(R.id.set_as_home_Screen_btn);
        button3=findViewById(R.id.set_as_lock_Screen_btn);


        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                if (mInterstitialAd.isLoaded()) {
                    mInterstitialAd.show();
                    downloadWallpaper();
                } else {
                    Toast.makeText(FullWallpaperScreenActivity.this, "Not Loaded Yet", Toast.LENGTH_SHORT).show();
                }


            }
        });

        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Home
                progressBar = new ProgressDialog(FullWallpaperScreenActivity.this);
                progressBar.setCancelable(false);
                progressBar.setMessage("File Loading ...");
                progressBar.setProgressStyle(ProgressDialog.STYLE_SPINNER);
                progressBar.show();


                final Handler handler = new Handler();
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        WallpaperManager wallpaperManager = WallpaperManager.getInstance(FullWallpaperScreenActivity.this);
                        Bitmap bitmap = ((BitmapDrawable) photoView.getDrawable()).getBitmap();
                        try {
                            wallpaperManager.setBitmap(bitmap);
                            progressBar.dismiss();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }, 2000);



            }
        });

        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Lock

                progressBar = new ProgressDialog(FullWallpaperScreenActivity.this);
                progressBar.setCancelable(false);
                progressBar.setMessage("File Loading ...");
                progressBar.setProgressStyle(ProgressDialog.STYLE_SPINNER);
                progressBar.show();


                final Handler handler = new Handler();
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        WallpaperManager wallpaperManager = WallpaperManager.getInstance(FullWallpaperScreenActivity.this);
                        Bitmap bitmap = ((BitmapDrawable) photoView.getDrawable()).getBitmap();
                        try {
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                                wallpaperManager.setBitmap(bitmap, null, true, WallpaperManager.FLAG_LOCK);

                                Toast.makeText(FullWallpaperScreenActivity.this, "Wallpaper Set", Toast.LENGTH_SHORT).show();
                            } else {
                                Toast.makeText(FullWallpaperScreenActivity.this, "Must Have Android 9 or Above", Toast.LENGTH_SHORT).show();
                            }
                            progressBar.dismiss();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }, 2000);

            }
        });



    }

    private void downloadWallpaper() {
        progressBar = new ProgressDialog(this);
        progressBar.setCancelable(false);
        progressBar.setMessage("File downloading ...");
        progressBar.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        progressBar.show();

        final Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {

                DownloadWallpaperEvent(imgLink);

            }
        }, 2000);

    }
    private void DownloadWallpaperEvent(String imgLink){

            File Maindir = this.getDir("Wallfy", Context.MODE_APPEND);
            if (!Maindir.exists()) {
                Maindir.mkdirs();
            }

            filename = UUID.randomUUID().toString();

            DownloadManager downloadManager = (DownloadManager) this.getSystemService(DOWNLOAD_SERVICE);
            Uri uri = Uri.parse(imgLink);
            DownloadManager.Request request = new DownloadManager.Request(uri);
            request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_ONLY_COMPLETION);
            request.setDestinationInExternalPublicDir("Wallfy/", filename + ".jpg");
            downloadManager.enqueue(request);
            Toast.makeText(this, "Downloading Complete", Toast.LENGTH_SHORT).show();
            progressBar.dismiss();



    }
}