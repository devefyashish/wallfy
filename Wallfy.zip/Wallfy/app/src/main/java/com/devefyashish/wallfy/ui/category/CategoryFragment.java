package com.devefyashish.wallfy.ui.category;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.devefyashish.wallfy.R;
import com.devefyashish.wallfy.WallPaperAdapter;

import java.util.ArrayList;
import java.util.List;

public class CategoryFragment extends Fragment {

    private RecyclerView recyclerView;
    private CategoryAdapter categoryAdapter;
    private List<CategoryModel> categoryModelList=new ArrayList<>();
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_category, container, false);
        recyclerView=view.findViewById(R.id.category_recyclerview);

        categoryModelList.add(new CategoryModel("Nature","https://pixabay.com/get/53e6d7454c55ad14f6da8c7dda7936761038d6e650526c48732f79d5934dc25fbe_1280.jpg"));
        categoryModelList.add(new CategoryModel("Science","https://pixabay.com/get/53e6d7434f54aa14f6da8c7dda7936761038d6e650526c48732f79d5934dc650b9_1280.jpg"));
        categoryModelList.add(new CategoryModel("Places","https://pixabay.com/get/53e6d5454b54ae14f6da8c7dda7936761038d6e650526c48732f79d5934dc058bb_1280.jpg"));
        categoryModelList.add(new CategoryModel("Animals","https://pixabay.com/get/53e6d5404e5baa14f6da8c7dda7936761038d6e650526c48732f79d5934dc05abc_1280.jpg"));
        categoryModelList.add(new CategoryModel("Music","https://pixabay.com/get/53e6d7464857a514f6da8c7dda7936761038d6e650526c48732f79d5934dc05cbb_1280.png"));
        categoryModelList.add(new CategoryModel("Sports","https://pixabay.com/get/53e6d7414b55af14f6da8c7dda7936761038d6e650526c48732f79d5934bc75eb9_1280.jpg"));


        categoryAdapter=new CategoryAdapter(categoryModelList,getContext());
        final GridLayoutManager gridLayoutManager = new GridLayoutManager(getContext(), 2, GridLayoutManager.VERTICAL, false);
        recyclerView.setLayoutManager(gridLayoutManager);
        recyclerView.setAdapter(categoryAdapter);
        categoryAdapter.notifyDataSetChanged();
        return view;
    }
}